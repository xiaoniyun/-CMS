<section class="container">
<div id="homeso">

<form method="get" id="homeso" style="text-align: center;float: none" action="seacher.php?wd=" >
<img src="images/sologo.png"><br/><br/>
<input tabindex="2" class="homesoin" id="sos" name="wd" type="text" placeholder="输入片名关键词" value="">
<button id="button" tabindex="3" class="homesobtn" type="submit">搜索</button>
</form>
</div>
</section>
